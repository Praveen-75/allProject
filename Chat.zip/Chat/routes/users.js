const mongoose = require("mongoose");
const plm = require("passport-local-mongoose");

mongoose.connect("mongodb://localhost/Chat");

const userSchema = mongoose.Schema({
     name: String,
     username: {
          type: String,
          unique: true
     },
     password: String,
     mobile: String
})

mongoose.plugin(plm);
module.exports = mongoose.model("user",userSchema);
