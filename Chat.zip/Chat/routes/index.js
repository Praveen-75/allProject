const express = require('express');
const router = express.Router();
const userModel = require("./users");
const msgModel = require("./users");
const multer = require("multer");
const localSteat = require("passport-local");
const passport = require('passport');

passport.use(new localSteat(userModel.authenticate()));


router.get('/', function(req, res, next) {
  res.render('index');
});

router.post("/login",passport.authenticate("local",{
  successRedirect: "/profile",
  failureRedirect: "/login"
}),function(req,res){})

function isLoggedIn(req,res, next){
  if(req.isAuthenticated()){
    return next();
  }
  res.redirect("/login")
}


router.get("/logout",function(req,res){
  req.logout(function(err){
    if(err) throw err
    res.redirect("/login")
  })
})

router.post("/register", function(req,res){
  const user = new userModel({
    name: req.body.name,
    username: req.body.username,
    mobile: req.body.mobile
  })
  userModel.register(user , req.body.password)
  .then(function(data){
    passport.authenticate('local')(req,res, function(){
      // res.redirect("/profile")
      res.send("done")
    })
  }).catch(function(e){
    res.send(e)
    // res.redirect("/")
  })
})


router.get('/profile',isLoggedIn, async function(req, res, next) {
  const user = await userModel.findOne({username: req.session.passport.user})
  res.render("profile",{user})
});

router.post("/msg",async function(req,res){
  const user = await userModel.findOne({username: req.session.passport.user})
  const cratemsg = await msgModel({
    userid: user._id,
    msg: req.body.msg
  })
  user.sentMsg.push(cratemsg._id)
  const saveMsg = user.save();
  const receiveMag = userModel.findOne({username: req.body.username})
})










module.exports = router;






// https://youtu.be/c01OHDUpDMU